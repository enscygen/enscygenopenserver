// static/js/drag_drop.js

document.addEventListener('DOMContentLoaded', () => {
    const dropArea = document.getElementById('drop-area');
    const fileInput = document.getElementById('file-input');
    // The uploadForm is used to get the action URL, but not for direct submission.
    const uploadForm = document.getElementById('upload-form'); 

    if (!dropArea || !fileInput || !uploadForm) {
        console.warn("Drag and drop elements or upload form not found. Skipping drag/drop functionality.");
        return;
    }

    // Get the folder_id from the form's action URL
    const folderId = uploadForm.action.split('/').pop();
    const uploadUrl = `/upload_file/${folderId}`;

    // Function to display flash messages (since Flask's flash won't work directly with fetch)
    function showFlashMessage(message, category) {
        const flashContainer = document.querySelector('main .mb-6'); // Assuming this is where flash messages appear
        if (!flashContainer) {
            console.warn("Flash message container not found.");
            return;
        }
        const messageDiv = document.createElement('div');
        messageDiv.classList.add('flash-message', `flash-${category}`);
        messageDiv.textContent = message;
        flashContainer.prepend(messageDiv); // Add to the top
        
        // Optional: remove after a few seconds
        setTimeout(() => {
            messageDiv.remove();
        }, 5000); // Remove after 5 seconds
    }

    // Function to handle file upload via Fetch API
    async function handleFileUpload(files) {
        if (files.length === 0) {
            showFlashMessage('No file selected.', 'danger');
            return;
        }

        const formData = new FormData();
        // Append each file under the name 'file' (matching Flask's request.files['file'])
        for (let i = 0; i < files.length; i++) {
            formData.append('file', files[i]);
        }

        try {
            const response = await fetch(uploadUrl, {
                method: 'POST',
                body: formData
            });

            const data = await response.json();

            if (response.ok) { // HTTP status 200-299
                showFlashMessage(data.message, 'success');
                // Redirect to refresh the folder details page to show new files
                window.location.href = data.redirect_url; 
            } else {
                showFlashMessage(data.message || 'An error occurred during upload.', 'danger');
            }
        } catch (error) {
            console.error('Upload failed:', error);
            showFlashMessage('Network error or server unreachable.', 'danger');
        }
    }

    // Prevent default drag behaviors
    ['dragenter', 'dragover', 'dragleave', 'drop'].forEach(eventName => {
        dropArea.addEventListener(eventName, preventDefaults, false);
        document.body.addEventListener(eventName, preventDefaults, false); // Prevent default for whole body
    });

    function preventDefaults(e) {
        e.preventDefault();
        e.stopPropagation();
    }

    // Highlight drop area when dragging file over it
    ['dragenter', 'dragover'].forEach(eventName => {
        dropArea.addEventListener(eventName, highlight, false);
    });

    ['dragleave', 'drop'].forEach(eventName => {
        dropArea.addEventListener(eventName, unhighlight, false);
    });

    function highlight() {
        dropArea.classList.add('highlight');
    }

    function unhighlight() {
        dropArea.classList.remove('highlight');
    }

    // Handle dropped files
    dropArea.addEventListener('drop', (e) => {
        unhighlight(); // Remove highlight immediately on drop
        const files = e.dataTransfer.files;
        handleFileUpload(files);
    }, false);

    // Allow clicking the drop area to open file dialog
    dropArea.addEventListener('click', () => {
        fileInput.click();
    });

    // When a file is selected via the click (hidden input), handle the upload
    fileInput.addEventListener('change', () => {
        handleFileUpload(fileInput.files);
    });

    // We can hide the manual upload form's button as JS handles submission
    // The form itself is already hidden in folder_details.html
    // If you want to explicitly hide the manual input if JS is active:
    // const manualFileInput = document.getElementById('manual-file-input');
    // const manualUploadButton = uploadForm.querySelector('button[type="submit"]');
    // if (manualFileInput && manualUploadButton) {
    //     manualFileInput.classList.add('hidden');
    //     manualUploadButton.classList.add('hidden');
    // }
});
